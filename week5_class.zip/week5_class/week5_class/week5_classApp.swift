//
//  week5_classApp.swift
//  week5_class
//
//  Created by Arch Umeshbhai Patel on 2025-06-06.
//

import SwiftUI

@main
struct week5_classApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
