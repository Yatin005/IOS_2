//
//  AuthFlow.swift
//  week5_class
//
//  Created by Arch Umeshbhai Patel on 2025-06-06.
//

import Foundation


enum AuthFlow{
    case signIn
    case signUp
    case home
}

