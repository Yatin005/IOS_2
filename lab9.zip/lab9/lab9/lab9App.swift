//
//  lab9App.swift
//  lab9
//
//  Created by Het Shah on 2025-08-15.
//

import SwiftUI

@main
struct lab9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
